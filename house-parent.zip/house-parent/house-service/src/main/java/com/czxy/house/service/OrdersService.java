package com.czxy.house.service;

import com.czxy.house.domain.Orders;

import java.util.List;

public interface OrdersService {

    public List<Orders> findAllOrder(String uid);

}
