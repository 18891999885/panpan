package com.czxy.house.service.impl;

import com.czxy.house.dao.OrdersMapper;
import com.czxy.house.domain.Orders;
import com.czxy.house.service.OrdersService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class OrdersServiceImpl implements OrdersService {

    @Resource
    private OrdersMapper ordersMapper;

    @Override
    public List<Orders> findAllOrder(String uid) {
        return ordersMapper.findAllOrders(uid);
    }
}


