package com.czxy.house.service;

import com.czxy.house.domain.Pact;

public interface PactService {
	//添加合同
	public void insert(Pact pact);
}
