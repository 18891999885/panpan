package com.czxy.house.service;

import java.util.List;

import com.czxy.house.domain.Orders;

public interface PayHomeService {

	public List<Orders> findAll(String oid);
	public void updataByOid(String oid);
	public void deleteByOid(String oid);
}
