package com.czxy.house.service;

import com.czxy.house.domain.HouseResource;
import com.czxy.house.domain.Landlord;
import org.springframework.stereotype.Service;


public interface LandlordService {

    public void addLandlord(Landlord landlord, HouseResource houseResource);

    void add(Landlord landlord);
}
