package com.czxy.house.service;

import com.czxy.house.domain.Village;
import org.springframework.stereotype.Service;

import java.util.List;


public interface VillageService {

    public List<Village> findAll();
}
