package com.czxy.house.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.czxy.house.dao.PayHomeMapper;
import com.czxy.house.domain.Orders;
import com.czxy.house.service.PayHomeService;
@Service
public class PayHomeServiceImpl implements PayHomeService {

	@Autowired
	private PayHomeMapper phm;
	
	
	public List<Orders> findAll(String oid) {
		List<Orders> findAll = phm.findAll(null);
		return findAll;
	}


	@Override
	public void updataByOid(String oid) {
		Orders orders = new Orders();
		orders.setOid(oid);
		orders.setOstate("待评价");
		phm.updateByPrimaryKeySelective(orders);
	}


	public void deleteByOid(String oid) {
		phm.deleteByPrimaryKey(oid);
	}



}
