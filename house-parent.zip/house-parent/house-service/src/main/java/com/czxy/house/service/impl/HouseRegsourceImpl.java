package com.czxy.house.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.czxy.house.dao.HouseResourceMapper;
import com.czxy.house.domain.HouseResource;
import com.czxy.house.service.HouseRegsourceService;

@Service
@Transactional
public class HouseRegsourceImpl implements HouseRegsourceService {

	@Autowired
	private HouseResourceMapper houseResourceMapper;

	public List<HouseResource> findAllHouse(String id) {

		List<HouseResource> list = houseResourceMapper.reFindAll(id);

		return list;
	}

	/**
	 * 热门查询所有
	 */
	public List<HouseResource> findAllHot() {

		List<HouseResource> list = houseResourceMapper.findAllHot();

		return list;
	}

	//根据房源id查询房源
	@Override
	public HouseResource showHouseResource(String houseId) {
		return houseResourceMapper.findHouseResource(houseId);
	}

	@Override
	public void add(HouseResource houseResource) {
		// TODO Auto-generated method stub
		houseResourceMapper.add(houseResource);
		
	}
}
