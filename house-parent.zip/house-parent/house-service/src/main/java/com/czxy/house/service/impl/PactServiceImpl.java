package com.czxy.house.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.czxy.house.dao.PactMapper;
import com.czxy.house.domain.Pact;
import com.czxy.house.service.PactService;
/**
 * 合同
 * @author 17674
 *
 */
@Service
@Transactional
public class PactServiceImpl implements PactService {

	@Autowired
	private PactMapper pactMapper;
	
	@Override
	public void insert(Pact pact) {
		pactMapper.insert(pact);
	}

}
