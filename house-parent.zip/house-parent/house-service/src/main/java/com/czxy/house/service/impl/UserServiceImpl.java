package com.czxy.house.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.czxy.house.dao.UserMapper;
import com.czxy.house.domain.User;
import com.czxy.house.service.UserService;
@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userMapper;
	/**
	 * 登陆
	 */
	@Override
	public User login(User user) {
		return userMapper.selectOne(user);
	}

	/**
	 * 注册
	 */
	@Override
	public void register(User user) {
		
		userMapper.insert(user);
	}

	@Override
	public List<User> selectAll() {
		List<User> selectAll = userMapper.selectAll();
		return selectAll;
	}

	@Override
	public void update(User user) {
		userMapper.updateByPrimaryKey(user);
	}
	
}
