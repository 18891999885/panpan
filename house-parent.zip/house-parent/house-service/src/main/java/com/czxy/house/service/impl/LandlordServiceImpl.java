package com.czxy.house.service.impl;

import com.czxy.house.dao.HouseResourceMapper;
import com.czxy.house.dao.LandlordMapper;
import com.czxy.house.dao.UserMapper;
import com.czxy.house.domain.HouseResource;
import com.czxy.house.domain.Landlord;
import com.czxy.house.domain.User;
import com.czxy.house.service.LandlordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LandlordServiceImpl implements LandlordService {
    @Autowired
    private LandlordMapper landlordMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private HouseResourceMapper houseResourceMapper;

    @Override
    public void addLandlord(Landlord landlord, HouseResource houseResource) {

        Landlord l =landlordMapper.selectLandlordNameAndPhone(landlord);
        if (l!=null){
            landlordMapper.updateLandlord(l);
        }else{
            landlordMapper.insertSelective(l);
        }
        HouseResource h = houseResourceMapper.selectID(houseResource);
        if (h!=null){
            houseResourceMapper.updateHouseResource(h);
        }else {
            houseResourceMapper.insertSelective(h);
        }

    }

    @Override
    public void add(Landlord landlord) {
        landlordMapper.insert(landlord);
    }
}
