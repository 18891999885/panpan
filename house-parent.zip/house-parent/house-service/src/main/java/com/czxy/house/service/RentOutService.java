package com.czxy.house.service;

import com.czxy.house.domain.RentOut;

import java.util.List;

public interface RentOutService {

    public List<RentOut> findAll();
}
