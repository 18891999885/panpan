package com.czxy.house.service.impl;

import com.czxy.house.dao.VillageMapper;
import com.czxy.house.domain.Village;
import com.czxy.house.service.VillageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class VillageServiceImpl implements VillageService {
    @Autowired
    private VillageMapper villageMapper;
    @Override
    public List<Village> findAll() {
        return villageMapper.selectAll();
    }
}
