package com.czxy.house.service;

import java.util.List;

import com.czxy.house.domain.HouseResource;

public interface HouseRegsourceService {

	/**
	 * 查询所有整租
	 */
	public List<HouseResource> findAllHouse(String id);
	
	/**
     * 热门查询所有
     */
    public List<HouseResource> findAllHot();
    
    //根据房源id查询房源
    public HouseResource showHouseResource(String houseId);
    
    public void add(HouseResource houseResource);
}
