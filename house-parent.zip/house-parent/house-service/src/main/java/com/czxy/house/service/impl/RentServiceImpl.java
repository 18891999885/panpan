package com.czxy.house.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.czxy.house.dao.RentMapper;
import com.czxy.house.domain.Region;
import com.czxy.house.domain.RentOut;
import com.czxy.house.service.RentService;

@Service
@Transactional
public class RentServiceImpl implements RentService {
	
	@Autowired
	private RentMapper rentMapper;
	/**
	 * 首页查询所有
	 */
	public List<RentOut> findAllRent() {
		
		List<RentOut> list = rentMapper.selectAll();
		
		return list;
	}
	
	
	/**
	 * 市查询所有
	 */
	public List<Region> findAllReg() {
		
		List<Region> list = rentMapper.findAllReg();
		
		return list;
	}

	
}
