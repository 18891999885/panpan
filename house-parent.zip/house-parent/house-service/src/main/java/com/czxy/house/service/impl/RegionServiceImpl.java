package com.czxy.house.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.czxy.house.dao.RegionMapper;
import com.czxy.house.domain.Region;
import com.czxy.house.service.RegionService;

@Service
@Transactional
public class RegionServiceImpl implements RegionService {

	@Autowired
	private RegionMapper regionMapper;
	
	public List<Region> findAll(String fid) {
		
		List<Region> list = regionMapper.findAll(fid);
		
//		Example example = new Example(Region.class);
//		Criteria criteria = example.createCriteria();
//		criteria.andEqualTo(fid);
//		
//		regionMapper.selectByExample(example);
		
		return list;
	}

}
