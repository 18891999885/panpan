package com.czxy.house.service;

import java.util.List;

import com.czxy.house.domain.Region;

public interface RegionService {

	public List<Region> findAll(String fid);
}
