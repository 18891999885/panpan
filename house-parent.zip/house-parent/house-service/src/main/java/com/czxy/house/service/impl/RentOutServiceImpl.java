package com.czxy.house.service.impl;

import com.czxy.house.dao.RentOutMapper;
import com.czxy.house.domain.RentOut;
import com.czxy.house.service.RentOutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RentOutServiceImpl implements RentOutService {
    @Autowired
    private RentOutMapper rentOutMapper;
    @Override
    public List<RentOut> findAll() {

        return rentOutMapper.selectAll();
    }
}
