package com.czxy.house.service;

import java.util.List;

import com.czxy.house.domain.Region;
import com.czxy.house.domain.RentOut;

public interface RentService {

	/**
	 * 首页查询所有
	 * @return
	 */
    public List<RentOut> findAllRent();
    
    /**
     * 市查询所有
     */
    public List<Region> findAllReg();
    
    
}
