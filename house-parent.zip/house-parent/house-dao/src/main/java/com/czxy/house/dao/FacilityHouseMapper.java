package com.czxy.house.dao;

import com.czxy.house.domain.FacilityHouse;
import org.apache.ibatis.annotations.*;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface FacilityHouseMapper extends Mapper<FacilityHouse> {

    @Select("select * from facility_house where  house_id = #{houseId}")
    @Results({
            @Result(property = "facilityId",column = "facility_id"),
            @Result(property = "houseId",column = "house_id"),
            @Result(property = "facility",column = "facility_id",many = @Many(select = "com.czxy.house.dao.FacilityMapper.selectByPrimaryKey")),
    })
    public List<FacilityHouse> findFacilityHouseByHouseId(@Param("houseId") String houseId);
}
