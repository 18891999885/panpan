package com.czxy.house.dao;

import com.czxy.house.domain.Facility;

import tk.mybatis.mapper.common.Mapper;

public interface FacilityMapper extends Mapper<Facility> {

}
