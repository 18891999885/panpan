package com.czxy.house.dao;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.czxy.house.domain.HouseResource;

import tk.mybatis.mapper.common.Mapper;

public interface HouseResourceMapper extends Mapper<HouseResource> {

	@Select("SELECT * FROM house_resource WHERE rent_out_id = #{id}")
	@Results({
		@Result(property="houseId",column="house_id"),
		@Result(property="descPict",column="desc_pict"),
		@Result(property="scale",column="scale"),
		@Result(property="area",column="area"),
		@Result(property="houseRent",column="house_rent"),
		@Result(property="finish",column="finish"),
		@Result(property="facilityId",column="facility_id"),
		//@Result(property="facility",column="facility_id"),
		@Result(property="plotId",column="plot_id"),
		@Result(property="village",column="plot_id",one=@One(select="com.czxy.house.dao.VillageMapper.selectByVid")),
		@Result(property="rentOutId",column="rent_out_id"),
		//@Result(property="rentOut",column="rent_out_id"),
		@Result(property="houseInfoId",column="house_info_id"),
		@Result(property="houseInfo",column="house_info_id",one=@One(select="com.czxy.house.dao.HouseInfoMapper.selectByInfoId")),
	})
	public List<HouseResource> reFindAll(String id);
	
	/**
	 *  热门查询所有
	 */
	
	@Select("SELECT * FROM house_resource")
	@Results({
		@Result(property="houseId",column="house_id"),
		@Result(property="descPict",column="desc_pict"),
		@Result(property="scale",column="scale"),
		@Result(property="area",column="area"),
		@Result(property="houseRent",column="house_rent"),
		@Result(property="finish",column="finish"),
		@Result(property="facilityId",column="facility_id"),
		//@Result(property="facility",column="facility_id"),
		@Result(property="plotId",column="plot_id"),
		@Result(property="village",column="plot_id",one=@One(select="com.czxy.house.dao.VillageMapper.selectByVid")),
		@Result(property="rentOutId",column="rent_out_id"),
		//@Result(property="rentOut",column="rent_out_id"),
		@Result(property="houseInfoId",column="house_info_id"),
		@Result(property="houseInfo",column="house_info_id",one=@One(select="com.czxy.house.dao.HouseInfoMapper.selectByInfoId")),
	})
	public List<HouseResource> findAllHot();
	
	@Select("select * from house_resource where house_id =#{hid}")
	@Results({
		@Result(property="houseId",column="house_id"),
		@Result(property="descPict",column="desc_pict"),
		@Result(property="scale",column="scale"),
		@Result(property="area",column="area"),
		@Result(property="houseRent",column="house_rent"),
		@Result(property="finish",column="finish"),
		@Result(property="facilityId",column="facility_id"),
		@Result(property="plotId",column="plot_id"),
		@Result(property="rentOutId",column="rent_out_id"),
		@Result(property="houseInfoId",column="house_info_id"),
		@Result(property="village",column="plot_id",many=@Many(select="com.czxy.house.dao.VillageMapper.selectByPrimaryKey"))
	})
	public HouseResource findHorseByid(@Param("hid")String hid);
	
	//lin
	@Select("select * from house_resource where house_id = #{houseId}")
    @Results({
            @Result(property = "houseId",column = "house_id"),
            @Result(property = "descPict",column = "desc_pict"),
            @Result(property = "scale",column = "scale"),
            @Result(property = "area",column = "area"),
            @Result(property = "houseRent",column = "house_rent"),
            @Result(property = "finish",column = "finish"),
            @Result(property = "facilityId",column = "facility_id"),
            @Result(property = "facilityHouse",column = "house_id",many = @Many(select = "com.czxy.house.dao.FacilityHouseMapper.findFacilityHouseByHouseId")),
            @Result(property = "plotId",column = "plot_id"),
            @Result(property = "village",column = "plot_id",one = @One(select = "com.czxy.house.dao.VillageMapper.findVillage")),
            @Result(property = "rentOutId",column = "rent_out_id"),
            @Result(property = "houseInfoId",column = "house_info_id"),
            @Result(property = "houseInfo",column = "house_info_id",one = @One(select = "com.czxy.house.dao.HouseInfoMapper.selectByPrimaryKey")),
    })
    public HouseResource findHouseResource(@Param("houseId") String houseId);
	
	@Select("select * from landlord where house_id='${houseResource.houseId}'")
    public HouseResource selectID(@Param("houseResource")HouseResource houseResource);

    @Select("UPDATE landlord SET scale='${houseResource.scale}',plot_id='${houseResource.plotId},rentOut_id='${houseResource.rentOutId}")
    public void updateHouseResource(@Param("houseResource")HouseResource houseResource);

    @Insert("INSERT INTO house_resource(house_id,scale,house_rent,plot_id,rent_out_id) VALUES (#{houseId},#{scale},#{houseRent},#{plotId},#{rentOutId})")
    public void add(HouseResource houseResource);
}
