package com.czxy.house.dao;

import com.czxy.house.domain.Pact;

import tk.mybatis.mapper.common.Mapper;

public interface PactMapper extends Mapper<Pact> {

}
