package com.czxy.house.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.czxy.house.domain.Region;
import com.czxy.house.domain.RentOut;

import tk.mybatis.mapper.common.Mapper;

public interface RentMapper extends Mapper<RentOut> {
	
	/**
	 * 查询所有的市
	 */
	
	@Select("SELECT `name` FROM region WHERE fid IS  NULL")
	public List<Region> findAllReg();
	
	
}
