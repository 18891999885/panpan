package com.czxy.house.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.czxy.house.domain.Region;

import tk.mybatis.mapper.common.Mapper;

public interface RegionMapper extends Mapper<Region> {
	
	@Select("SELECT * FROM region WHERE fid = #{fid}")
	public List<Region> findAll(String fid);

}
