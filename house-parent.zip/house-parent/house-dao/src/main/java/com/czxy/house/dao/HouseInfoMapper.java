package com.czxy.house.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.czxy.house.domain.HouseInfo;

import tk.mybatis.mapper.common.Mapper;

public interface HouseInfoMapper extends Mapper<HouseInfo> {

	@Select("SELECT * FROM house_info WHERE house_info_id=#{id}")
	public List<HouseInfo> selectByInfoId(String id);
}
