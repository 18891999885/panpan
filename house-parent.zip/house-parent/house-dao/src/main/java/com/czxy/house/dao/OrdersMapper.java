package com.czxy.house.dao;

import com.czxy.house.domain.Orders;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;


@Repository
public interface OrdersMapper extends Mapper<Orders> {

    @Select("select * from orders where uid = #{uid}")
    @Results({
            @Result(property = "oid",column = "oid"),
            @Result(property = "ostate",column = "ostate"),
            @Result(property = "starttime",column = "starttime"),
            @Result(property = "endtime",column = "endtime"),
            @Result(property = "tenancy",column = "tanancy"),
            @Result(property = "elsemoney",column = "elsemoney"),
            @Result(property = "commission",column = "commission"),
            @Result(property = "user",column = "uid",one = @One(select = "com.czxy.house.dao.UserMapper.selectByPrimaryKey")),
            @Result(property = "uid",column = "uid"),
            @Result(property = "houseResource",column = "house_id",one = @One(select = "com.czxy.house.dao.HouseResourceMapper.findHouseResource")),
            @Result(property = "houseId",column = "house_id"),
            @Result(property = "lookHouseTime",column = "look_house_time")
    })
    public List<Orders> findAllOrders(@Param("uid") String uid);

}
