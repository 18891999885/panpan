package com.czxy.house.dao;

import java.util.List;

import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.czxy.house.domain.Orders;

import tk.mybatis.mapper.common.Mapper;

public interface PayHomeMapper extends Mapper<Orders> {

	@Select("select * from orders where oid = #{oid} or 1=1")
	@Results({
		@Result(property="oid",column="oid"),
		@Result(property="houseId",column="house_id"),
		@Result(property="uid",column="uid"),
		@Result(property="ostate",column="ostate"),
		@Result(property="starttime",column="starttime"),
		@Result(property="endtime",column="endtime"),
		@Result(property="tenancy",column="tenancy"),
		@Result(property="elsemoney",column="elsemoney"),
		@Result(property="commission",column="commission"),
		@Result(property="houseResource",column="house_id",many=@Many(select="com.czxy.house.dao.HouseResourceMapper.findHorseByid"))
	})
	public List<Orders> findAll(String oid);
	
	
	
	
}
