package com.czxy.house.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.czxy.house.domain.Village;

import tk.mybatis.mapper.common.Mapper;

public interface VillageMapper extends Mapper<Village> {

	@Select("SELECT * FROM village WHERE plot_id= #{vid}")
	public List<Village> selectByVid(String vid);
	
	
	 @Select("select * from village where plot_id = #{plotId}")
	    @Results({
	            @Result(property = "plotId",column = "plot_id"),
	            @Result(property = "plotName",column = "plot_name"),
	            @Result(property = "uid",column = "uid"),
	            @Result(property = "landlordId",column = "landlord"),
	            @Result(property = "id",column = "id"),
	            @Result(property = "region",column = "id",one = @One(select = "com.czxy.house.dao.RegionMapper.selectByPrimaryKey"))
	    })
	    public Village findVillage(@Param("plotId") String plotId);
	
}
