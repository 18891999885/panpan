package com.czxy.house.dao;

import com.czxy.house.domain.Landlord;
import org.apache.ibatis.annotations.*;
import tk.mybatis.mapper.common.Mapper;

public interface LandlordMapper extends Mapper<Landlord> {
    @Select("select * from landlord where landlord_name='${landlord.landlordName}' and phone='${landlord.phone}'")
    public Landlord selectLandlordNameAndPhone(@Param("labdlord")Landlord landlord);
    @Select("UPDATE landlord SET landlord_date='${landlord.landlordDate}',house_id='${landlord.houseId}';")
    public void updateLandlord(@Param("labdlord")Landlord landlord);



}
