package com.czxy.house.controller;

import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aliyuncs.exceptions.ClientException;
import com.czxy.house.domain.User;
import com.czxy.house.service.UserService;

import cn.itcast.aliyun.SmsSender;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	/**
	 * 登陆功能
	 * 
	 * @param model
	 * @param user
	 * @return
	 */
	@RequestMapping("/login.action")
	public String login(Model model, User user) {

		User loginUser = userService.login(user);

		if (loginUser != null) {
			model.addAttribute("loginUser", loginUser);
			return "/p-center";
		} else {
			model.addAttribute("msg", "账号或密码输入错误，请重新输入");
			return "/sign";
		}
	}
	
	//修改密码--3验证短信验证码
	@RequestMapping("/checkSms.action")
	public String checkSms(String writesms,HttpSession session,Model model){
		String sms =(String) session.getAttribute("sms");
		if(writesms.equals(sms)){
			return "/lose";
		}
		model.addAttribute("filureMsg", "验证码有误");
		return "/short";
	}
	

	/**
	 * 注册
	 * 
	 * @param model
	 * @param user
	 * @return
	 */
	@RequestMapping("/register.action")
	public String register(Model model, User user, String repassword, String password) {
		UUID uuid = UUID.randomUUID();
		String string = uuid.toString();
		String replace = string.replace("-", "");
		user.setUid(replace);

		String dh = "";
		List<User> userAll = userService.selectAll();
		for (User thisUser : userAll) {

			dh = thisUser.getTelephone();
		}
		if (user.getTelephone().equals(dh)) {
			model.addAttribute("msg", "手机号已存在，请重新输入");
			return "/register";
		} else {
			if (user.getPassword().equals(repassword)) {
				userService.register(user);
				return "/sign";
			} else {
				model.addAttribute("msg", "两次输入密码不一致，请重新输入");
				model.addAttribute("user", user);
				return "/register";
			}
		}
	}
/**
 * 修改密码
 * @param model
 * @param verification
 * @param session
 * @param accountnumber
 * @return
 */
	@RequestMapping("/updatePassword.action")
	public String updatePassword(Model model, String verification, HttpSession session, String accountnumber) {
		String yzm = (String) session.getAttribute("yzm");
		List<User> userAll = userService.selectAll();

		String telephone = "";
		String username = "";

		for (User user : userAll) {
			telephone = user.getTelephone();
			username = user.getUsername();
		}
		if (!yzm.equalsIgnoreCase(verification)) {
			model.addAttribute("msg", "验证码输入错误，请重新输入");
			return "/modify";
		} else {
			if (!accountnumber.equals(telephone) && !accountnumber.equals(username)) {
				model.addAttribute("msg", "您输入的账号不正确，请重新输入");
				return "/modify";
			}
			
			model.addAttribute("telephone",telephone);
			return "/short";

		}

	}
	
	
	/**
	 * 短信验证
	 * @param phone
	 * @param session
	 * @return
	 * @throws ClientException
	 * @throws InterruptedException
	 */
	@RequestMapping("/sendSMS.action")
	public String send(String phone,HttpSession session) throws ClientException, InterruptedException{
		String yzm ="666666";
		new SmsSender("sms.properties").send(phone, yzm);
		session.setAttribute("sms", yzm);
		System.out.println("qwe123");
		return "/short";
	}
	
	@RequestMapping("/judgePsw.action")
	public String judgePsw(Model model,User user,String repassword){
		if (user.getPassword().equals(repassword)) {
			userService.update(user);
			return "/complete";
		}
		model.addAttribute("msg", "两次输入的密码不一致，请重新输入");
		return "/lose";
	}
	
	
	/**
	 * 随机验证码
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping("/getImage.action")
	public String getImage(Model model, HttpSession session) {
		Random random = new Random();
		String[] str = { "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "L", "K", "J", "H", "G", "F", "D", "S", "A",
				"Z", "X", "C", "V", "B", "N", "M", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
		String yzm = "";
		for (int i = 0; i < 2; i++) {
			int nextInt = random.nextInt(str.length);
			int randoms = new Random().nextInt(10);
			yzm += str[nextInt];
			yzm += randoms;
		}
		session.setAttribute("yzm", yzm);
		return "/modify";
	}

}
