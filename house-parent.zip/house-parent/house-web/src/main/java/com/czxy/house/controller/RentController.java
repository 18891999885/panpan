package com.czxy.house.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.czxy.house.domain.Region;
import com.czxy.house.domain.RentOut;
import com.czxy.house.service.RentService;

@Controller
@RequestMapping(path="/rent")
public class RentController {
	
	@Autowired
	private RentService rentService;
	
	/**
	 * 首页查询所有
	 */
	@RequestMapping(path="/findAllRent.action")
	public @ResponseBody List<RentOut> findAllRent(Model model){
		List<RentOut> list = rentService.findAllRent();
		model.addAttribute("list", list);
		return list;
	}
	
	/**
	 * 市查询所有
	 */
	@RequestMapping(path="/findAllReg.action")
	public @ResponseBody List<Region> findAllReg(){
		List<Region> list = rentService.findAllReg();
		return list;
	}
	
	
}
