package com.czxy.house.controller;

import com.czxy.house.domain.Orders;
import com.czxy.house.service.OrdersService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/orders")
public class OrderController {

    @Resource
    private OrdersService ordersService;

    @RequestMapping("/orderLoading")
    public String orderLoading(Model model,String uid){
        List<Orders> allOrder = ordersService.findAllOrder(uid);
        long nowTime = new Date().getTime();
        for (Orders orders : allOrder) {
            if (orders.getLookHouseTime().getTime() > nowTime){
                model.addAttribute("orderList",allOrder);
                System.out.println(orders);
            }
        }
        return "schedule2";
    }

    @RequestMapping("/orderFinish")
    public String orderFinish(Model model,String uid){
        List<Orders> allOrder = ordersService.findAllOrder(uid);
        long nowTime = new Date().getTime();
        for (Orders orders : allOrder) {
            if (orders.getLookHouseTime().getTime() < nowTime){
                model.addAttribute("orderList",allOrder);
                System.out.println(orders);
            }
        }
        return "schedule";
    }
}
