package com.czxy.house.controller;

import com.czxy.house.domain.Village;
import com.czxy.house.service.VillageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
@Controller
@RequestMapping("/village")
public class VillageController {
    @Autowired
    private VillageService villageService;

    @RequestMapping("/findAll.action")
    public @ResponseBody List<Village> findAll(){
        List<Village> list = villageService.findAll();
        return list;
    }
}
