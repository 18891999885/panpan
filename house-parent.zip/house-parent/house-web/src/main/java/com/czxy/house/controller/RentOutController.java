package com.czxy.house.controller;

import com.czxy.house.domain.RentOut;
import com.czxy.house.service.RentOutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/RentOut")
public class RentOutController {
    @Autowired
    private RentOutService rentOutService;
    @RequestMapping("/findAll")
    public @ResponseBody List<RentOut> findAll(){
        List<RentOut> list = rentOutService.findAll();
        return list;
    }
}
