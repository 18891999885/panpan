package com.czxy.house.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.czxy.house.domain.Orders;
import com.czxy.house.service.PayHomeService;

@Controller
public class PayHomeController {

	@Autowired
	private PayHomeService phs;
	
	@RequestMapping("schedule.action")
	public String findAll(Model model){
		List<Orders> findAll = phs.findAll(null);
		model.addAttribute("list",findAll);
		return "schedule";
	}
	
	
	@RequestMapping("rentOrder.action")
	public String findAll2(Model model){
		List<Orders> findAll = phs.findAll(null);
		model.addAttribute("list",findAll);
		return "rent-order";
	}
	

	@RequestMapping("rent-order.action")
	public String findAll3(Model model){
		List<Orders> findAll = phs.findAll(null);
		model.addAttribute("list",findAll);
		return "rent-order";
	}
	
	
	@RequestMapping("empty-list.action")
	public String findAll4(Model model){
		List<Orders> findAll = phs.findAll(null);
		model.addAttribute("list",findAll);
		return "empty-list";
	}
	
	
	@RequestMapping("emptyList.action")
	public String findAll5(Model model){
		List<Orders> findAll = phs.findAll(null);
		model.addAttribute("list",findAll);
		return "empty-list";
	}
	@RequestMapping("pay-rent.action")
	public String findByOid(String oid,HttpSession session){
		System.out.println(oid);
		List<Orders> findAll = phs.findAll(oid);
		System.out.println(findAll);
		//model.addAttribute("list",findAll);
		session.setAttribute("list", findAll);
		return "pay-rent";
	}
	
	@RequestMapping("success.action")
	public String updataByOid(String oid){
		System.out.println(oid);
			phs.updataByOid(oid);
		return "success";
	}
	
	
	@RequestMapping("assess.action")
	public String updataEvaByOid(String oid,Model model){
		System.out.println(oid);
		List<Orders> findAll = phs.findAll(oid);
		model.addAttribute("list", findAll);
		return "assess";
	}
	
	
	@RequestMapping("appends.action")
	public String insterByOid(Orders orders){
		System.out.println(orders);
		return "success";
	}
	
	
	@RequestMapping("cancel.action")
	public String deleteByOid(String oid){
		phs.deleteByOid(oid);
		return "redirect:/rentOrder.action";
	}
}
