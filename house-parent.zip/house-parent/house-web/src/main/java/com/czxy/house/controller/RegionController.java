package com.czxy.house.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.czxy.house.domain.Region;
import com.czxy.house.service.RegionService;

@Controller
@RequestMapping(path="/region")
public class RegionController {

	@Autowired
	private RegionService regionService;
	
	@RequestMapping(path="/findAll.action")
	public @ResponseBody List<Region> findAll(String fid){
		System.out.println("+++"+fid);
		List<Region> list = regionService.findAll(fid);
		
		return list;
	}
}
