package com.czxy.house.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@ComponentScan(basePackages={"com.czxy.house.controller","cn.tf.pay"})
@EnableWebMvc
public class MVCConfiguration extends WebMvcConfigurerAdapter {
	/**
	 * 视图解析器
	 * @return
	 */
	@Bean
	public InternalResourceViewResolver internalResourceViewResolver(){
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		//前缀 jsp文件夹
		viewResolver.setPrefix("/");
		//后缀 jsp扩展名
		viewResolver.setSuffix(".jsp");
		return viewResolver;
	}
	
	@Bean
	public CommonsMultipartResolver multipartResolver(){
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		multipartResolver.setMaxUploadSize(5242880);
		multipartResolver.setMaxInMemorySize(4096);
		multipartResolver.setDefaultEncoding("UTF-8");
		return multipartResolver;
	}

}
