package com.czxy.house.controller;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.czxy.house.domain.Pact;
import com.czxy.house.domain.User;
import com.czxy.house.service.PactService;
/**
 * 合同
 * @author 17674
 *
 */
@Controller
@RequestMapping("/pact")
public class PactController {
	private PactService pactService;
	
	
	//查询所有合同
	@RequestMapping("/findAll.action")
	public Pact name() {
		
		
		return null;
	}
	
	
	//上传图片
	@RequestMapping("/addPact.action")
	public String contract(MultipartFile images,HttpSession httpSession){
		//用户
		User user = (User)httpSession.getAttribute("loginUser");
		//设置id
		Pact pact = new Pact();
		pact.setUid("u001");
		pact.setPactId("p"+new Random().nextInt(100)+"");
		pact.setImages(images.getName());
		System.out.println(images.getOriginalFilename()+"***");
		//pactService.insert(pact);
		return "/contract";
	}
	
	
}	
