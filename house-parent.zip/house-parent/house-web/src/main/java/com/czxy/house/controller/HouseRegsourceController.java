package com.czxy.house.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.czxy.house.domain.HouseResource;
import com.czxy.house.service.HouseRegsourceService;

@Controller
@RequestMapping(path="/house")
public class HouseRegsourceController {

	@Autowired
	private HouseRegsourceService houseRegsourceService;
	
	@RequestMapping(path="/reFindAll.action")
	public String reFindAll(String id,Model model){
		System.out.println("==========="+id);
		List<HouseResource> list = houseRegsourceService.findAllHouse(id);
		model.addAttribute("list", list);
		for (HouseResource houseResource : list) {
			System.out.println("sssssssssssss"+houseResource);
		}
		
		return "entire";
		
	}
	
	/**
	 * 热门查询所有
	 */
	@RequestMapping(path="/hot.action")
	public @ResponseBody List<HouseResource> findAllHot(Model model){
		
		List<HouseResource> list = houseRegsourceService.findAllHot();
		
		model.addAttribute("list", list);
		
		return list;
	}
	
	//根据id查询
    @RequestMapping("/showHouseInfo")
    public String showHouseInfo(Model model,String id){
        HouseResource houseResource = houseRegsourceService.showHouseResource(id);
       System.out.println("^^^"+houseResource);
        model.addAttribute("house",houseResource);
        return "house-details";
    }
}
