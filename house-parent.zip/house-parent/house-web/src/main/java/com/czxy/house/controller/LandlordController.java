package com.czxy.house.controller;

import com.czxy.house.domain.HouseResource;
import com.czxy.house.domain.Landlord;
import com.czxy.house.domain.LandlordVo;
import com.czxy.house.service.HouseRegsourceService;
import com.czxy.house.service.LandlordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.UUID;

@Controller
public class LandlordController {
    @Resource
    private LandlordService landlordService;
    @Resource
    private HouseRegsourceService houseResourceService;
    @RequestMapping("/add.action")
    public String addLandlord(LandlordVo landlordVo){

        HouseResource houseResource = new HouseResource();
        Landlord landlord = new Landlord();

        UUID uuid = UUID.randomUUID();
        String string = uuid.toString();
        String s = string.replace("-", "");

        houseResource.setScale(landlordVo.getScale());
        houseResource.setPlotId(landlordVo.getVillage());
        houseResource.setHouseId(s);
        houseResource.setRentOutId(landlordVo.getRentOut());
        houseResource.setHouseRent(landlordVo.getHouseRent());
        
        UUID uuid1 = UUID.randomUUID();
        String string1 = uuid1.toString();
        String s1 = string.replace("-", "");
        landlord.setLandlordId(s1);
        landlord.setLandlordName(landlordVo.getLandlordName());
        landlord.setLandlordDate(landlordVo.getLandlordDate());
        landlord.setPhone(landlordVo.getPhone());
        landlord.setHouseId(s);

        System.err.println(s);
        landlordService.add(landlord);
        houseResourceService.add(houseResource);
        return "index";
    }
}
