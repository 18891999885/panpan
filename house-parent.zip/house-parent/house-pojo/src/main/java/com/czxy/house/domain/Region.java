package com.czxy.house.domain;
/*
 * 市，区，二级联动表
 */
public class Region {
    private String name;	//市，区，名称

    private String id;		//市，区，id

    private String fid;		//市，id null为市

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid == null ? null : fid.trim();
    }

	@Override
	public String toString() {
		return "Region [name=" + name + ", id=" + id + ", fid=" + fid + "]";
	}
    
}