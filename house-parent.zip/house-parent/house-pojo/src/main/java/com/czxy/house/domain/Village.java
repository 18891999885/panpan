package com.czxy.house.domain;
/*
 * 小区
 */
public class Village {
    private String plotId;		//小区id

    private String plotName;	//小区名称

    private String uid;			//用户id
    private User user;			//用户对象

    private String landlordId;	//房东id
    private Landlord landlord;	//房东对象

    private String id;			//市，区id
    private Region region;		//市，区对象
	public String getPlotId() {
		return plotId;
	}
	public void setPlotId(String plotId) {
		this.plotId = plotId;
	}
	public String getPlotName() {
		return plotName;
	}
	public void setPlotName(String plotName) {
		this.plotName = plotName;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getLandlordId() {
		return landlordId;
	}
	public void setLandlordId(String landlordId) {
		this.landlordId = landlordId;
	}
	public Landlord getLandlord() {
		return landlord;
	}
	public void setLandlord(Landlord landlord) {
		this.landlord = landlord;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Region getRegion() {
		return region;
	}
	public void setRegion(Region region) {
		this.region = region;
	}
	public Village(String plotId, String plotName, String uid, User user, String landlordId, Landlord landlord,
			String id, Region region) {
		super();
		this.plotId = plotId;
		this.plotName = plotName;
		this.uid = uid;
		this.user = user;
		this.landlordId = landlordId;
		this.landlord = landlord;
		this.id = id;
		this.region = region;
	}
	public Village() {
		super();
	}
	@Override
	public String toString() {
		return "Village [plotId=" + plotId + ", plotName=" + plotName + ", uid=" + uid + ", user=" + user
				+ ", landlordId=" + landlordId + ", landlord=" + landlord + ", id=" + id + ", region=" + region + "]";
	}

    
}