package com.czxy.house.domain;


/*
 *	合同
 */
public class Pact {
    private String pactId;	//合同id

    private String images;	//图片

    private String uid;		//用户id
    private User user; //用户对象
	public String getPactId() {
		return pactId;
	}
	public void setPactId(String pactId) {
		this.pactId = pactId;
	}
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Pact(String pactId, String images, String uid, User user) {
		super();
		this.pactId = pactId;
		this.images = images;
		this.uid = uid;
		this.user = user;
	}
	public Pact() {
		super();
	}
	@Override
	public String toString() {
		return "Pact [pactId=" + pactId + ", images=" + images + ", uid=" + uid + ", user=" + user + "]";
	}

    
}