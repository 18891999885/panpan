package com.czxy.house.domain;


/*
 * 余额表
 */
public class Balance {
    private String balanceId;	//余额id

    private Double income;		//收入

    private Double outcome;		//支出

    private String uid;			//用户id
    private User user;			//用户对象
	public String getBalanceId() {
		return balanceId;
	}
	public void setBalanceId(String balanceId) {
		this.balanceId = balanceId;
	}
	public Double getIncome() {
		return income;
	}
	public void setIncome(Double income) {
		this.income = income;
	}
	public Double getOutcome() {
		return outcome;
	}
	public void setOutcome(Double outcome) {
		this.outcome = outcome;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	@Override
	public String toString() {
		return "Balance [balanceId=" + balanceId + ", income=" + income + ", outcome=" + outcome + ", uid=" + uid
				+ ", user=" + user + "]";
	}
	public Balance(String balanceId, Double income, Double outcome, String uid, User user) {
		super();
		this.balanceId = balanceId;
		this.income = income;
		this.outcome = outcome;
		this.uid = uid;
		this.user = user;
	}
	public Balance() {
		super();
	}
    
    
}