package com.czxy.house.domain;

import java.util.Date;
/*
 * 优惠券
 */
public class Coupon {
    private String couponId;	//优惠券id

    private String couponName;	//优惠券名称

    private String couponMoney;	//优惠金额

    private Date usableDate;	//可用时间

    public String getCouponId() {
        return couponId;
    }

    public void setCouponId(String couponId) {
        this.couponId = couponId == null ? null : couponId.trim();
    }

    public String getCouponName() {
        return couponName;
    }

    public void setCouponName(String couponName) {
        this.couponName = couponName == null ? null : couponName.trim();
    }

    public String getCouponMoney() {
        return couponMoney;
    }

    public void setCouponMoney(String couponMoney) {
        this.couponMoney = couponMoney == null ? null : couponMoney.trim();
    }

    public Date getUsableDate() {
        return usableDate;
    }

    public void setUsableDate(Date usableDate) {
        this.usableDate = usableDate;
    }
}