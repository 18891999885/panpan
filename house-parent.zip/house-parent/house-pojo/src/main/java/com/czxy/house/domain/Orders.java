package com.czxy.house.domain;

import java.util.Date;

import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

/*
 * 订单
 */
public class Orders {
	@Id
    private String oid;	//订单id

    private String houseId;	//房源id
    private HouseResource houseResource;	//房源对象

    private String uid;	//用户id
    private User user; //用户对象

    private String ostate;	//订单状态
    @DateTimeFormat(pattern="yyyy-MM-dd")		//非json数据
    private Date starttime;	//合同开始时间
    @DateTimeFormat(pattern="yyyy-MM-dd")		//非json数据
    private Date endtime;	//合同结束时间

    private Integer tenancy;	//租用日期

    private Double elsemoney;	//其他费用

    private Double commission;	//平台佣金
    
    private Date lookHouseTime;

    private String eva;  		//评论

    private String grades;		//等级
    
	public String getOid() {
		return oid;
	}

	public Date getLookHouseTime() {
		return lookHouseTime;
	}

	public void setLookHouseTime(Date lookHouseTime) {
		this.lookHouseTime = lookHouseTime;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getHouseId() {
		return houseId;
	}

	public void setHouseId(String houseId) {
		this.houseId = houseId;
	}

	public HouseResource getHouseResource() {
		return houseResource;
	}

	public void setHouseResource(HouseResource houseResource) {
		this.houseResource = houseResource;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getOstate() {
		return ostate;
	}

	public void setOstate(String ostate) {
		this.ostate = ostate;
	}

	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}

	public Integer getTenancy() {
		return tenancy;
	}

	public void setTenancy(Integer tenancy) {
		this.tenancy = tenancy;
	}

	public Double getElsemoney() {
		return elsemoney;
	}

	public void setElsemoney(Double elsemoney) {
		this.elsemoney = elsemoney;
	}

	public Double getCommission() {
		return commission;
	}

	public void setCommission(Double commission) {
		this.commission = commission;
	}


	public Orders() {
		super();
	}

	public String getEva() {
		return eva;
	}

	public void setEva(String eva) {
		this.eva = eva;
	}

	public String getGrades() {
		return grades;
	}

	public void setGrades(String grades) {
		this.grades = grades;
	}

	@Override
	public String toString() {
		return "Orders [oid=" + oid + ", houseId=" + houseId + ", houseResource=" + houseResource + ", uid=" + uid
				+ ", user=" + user + ", ostate=" + ostate + ", starttime=" + starttime + ", endtime=" + endtime
				+ ", tenancy=" + tenancy + ", elsemoney=" + elsemoney + ", commission=" + commission
				+ ", lookHouseTime=" + lookHouseTime + ", eva=" + eva + ", grades=" + grades + "]";
	}

}