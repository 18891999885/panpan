package com.czxy.house.domain;

import javax.persistence.Id;

/*
 * 用户
 */
public class User {
	@Id
    private String uid;		//用户id

    private String username;	//用户名称

    private String password;	//用户密码

    private String telephone;	//用户电话

    private String asseteId;	//资产id
    private Assets assets;		//资产对象
    private String uimage;		//用户头像
    
    
    
	public String getUimage() {
		return uimage;
	}
	public void setUimage(String uimage) {
		this.uimage = uimage;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getAsseteId() {
		return asseteId;
	}
	public void setAsseteId(String asseteId) {
		this.asseteId = asseteId;
	}
	public Assets getAssets() {
		return assets;
	}
	public void setAssets(Assets assets) {
		this.assets = assets;
	}
	
	public User(String uid, String username, String password, String telephone, String asseteId, Assets assets,
			String uimage) {
		super();
		this.uid = uid;
		this.username = username;
		this.password = password;
		this.telephone = telephone;
		this.asseteId = asseteId;
		this.assets = assets;
		this.uimage = uimage;
	}
	public User() {
		super();
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", username=" + username + ", password=" + password + ", telephone=" + telephone
				+ ", asseteId=" + asseteId + ", assets=" + assets + ", uimage=" + uimage + "]";
	}
    
}