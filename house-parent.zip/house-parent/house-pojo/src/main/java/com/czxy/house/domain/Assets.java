package com.czxy.house.domain;


/*
 * 我的资产
 */
public class Assets {
    private String assetsId;	//资产id

    private String balanceId;	//余额id
    private Balance balance;	//余额对象

    private String integral;	//积分

    private String couponId;	//优惠券id
    private Coupon coupon;
	public String getAssetsId() {
		return assetsId;
	}
	public void setAssetsId(String assetsId) {
		this.assetsId = assetsId;
	}
	public String getBalanceId() {
		return balanceId;
	}
	public void setBalanceId(String balanceId) {
		this.balanceId = balanceId;
	}
	public Balance getBalance() {
		return balance;
	}
	public void setBalance(Balance balance) {
		this.balance = balance;
	}
	public String getIntegral() {
		return integral;
	}
	public void setIntegral(String integral) {
		this.integral = integral;
	}
	public String getCouponId() {
		return couponId;
	}
	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}
	public Assets(String assetsId, String balanceId, Balance balance, String integral, String couponId, Coupon coupon) {
		super();
		this.assetsId = assetsId;
		this.balanceId = balanceId;
		this.balance = balance;
		this.integral = integral;
		this.couponId = couponId;
		this.coupon = coupon;
	}
	public Assets() {
		super();
	}
	@Override
	public String toString() {
		return "Assets [assetsId=" + assetsId + ", balanceId=" + balanceId + ", balance=" + balance + ", integral="
				+ integral + ", couponId=" + couponId + ", coupon=" + coupon + "]";
	}
    
    
}