package com.czxy.house.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.ibatis.type.JdbcType;

import tk.mybatis.mapper.annotation.ColumnType;
/*
 * 房屋信息
 */
@Table(name="house_info")
public class HouseInfo {
	@Id
    private String houseInfoId;		//房屋信息id

    private String houseType;		//房屋类型

    private String orientation;		//朝向
    
    private String floor;			//楼层

    private String renovation;		//装修

    private String state;			//出租状态

    @Column(name="checkin_time")
    @ColumnType(jdbcType=JdbcType.DATE)
    private Date checkinTime;		//入住时间

    private String constructionTime;//建造时间

    @Column(name="looktime")
    @ColumnType(jdbcType=JdbcType.DATE)
    private Date looktime;			//可看房时间

    private String traffic;			//附近交通
    
    public String getHouseInfoId() {
        return houseInfoId;
    }

    public void setHouseInfoId(String houseInfoId) {
        this.houseInfoId = houseInfoId == null ? null : houseInfoId.trim();
    }

    public String getHouseType() {
        return houseType;
    }

    public void setHouseType(String houseType) {
        this.houseType = houseType == null ? null : houseType.trim();
    }

    public String getOrientation() {
        return orientation;
    }

    public void setOrientation(String orientation) {
        this.orientation = orientation == null ? null : orientation.trim();
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor == null ? null : floor.trim();
    }

    public String getRenovation() {
        return renovation;
    }

    public void setRenovation(String renovation) {
        this.renovation = renovation == null ? null : renovation.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public Date getCheckinTime() {
        return checkinTime;
    }

    public void setCheckinTime(Date checkinTime) {
        this.checkinTime = checkinTime;
    }

    public String getConstructionTime() {
        return constructionTime;
    }

    public void setConstructionTime(String constructionTime) {
        this.constructionTime = constructionTime == null ? null : constructionTime.trim();
    }

    public Date getLooktime() {
        return looktime;
    }

    public void setLooktime(Date looktime) {
        this.looktime = looktime;
    }

    public String getTraffic() {
        return traffic;
    }

    public void setTraffic(String traffic) {
        this.traffic = traffic == null ? null : traffic.trim();
    }
}