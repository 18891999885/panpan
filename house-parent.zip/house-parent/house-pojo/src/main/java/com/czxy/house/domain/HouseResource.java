package com.czxy.house.domain;

import javax.persistence.Id;
import javax.persistence.Table;
import java.util.List;

@Table(name = "house_resource")
public class HouseResource {
	@Id
	private String houseId;// 房源id

	private String himage; // 房源图片
	private String descPict; // 描述
	private String scale;// 户型
	private String area; // 面积
	private Double houseRent; // 租金
	private String finish;// 装修类型
	private String facilityId; // 配置id
	private Facility facility; // 配置对象
	private String plotId;// 小区id
	private Village village;// 小区对象
	private String rentOutId;// 出租类型id
	private RentOut rentOut; // 出租类型
	private String houseInfoId;// 房屋信息id
	private HouseInfo houseInfo;// 房屋信息对象
	private List<FacilityHouse> facilityHouse;

	public String getHouseId() {
		return houseId;
	}

	public void setHouseId(String houseId) {
		this.houseId = houseId;
	}

	public String getHimage() {
		return himage;
	}

	public void setHimage(String himage) {
		this.himage = himage;
	}

	public String getDescPict() {
		return descPict;
	}

	public void setDescPict(String descPict) {
		this.descPict = descPict;
	}

	public String getScale() {
		return scale;
	}

	public void setScale(String scale) {
		this.scale = scale;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Double getHouseRent() {
		return houseRent;
	}

	public void setHouseRent(Double houseRent) {
		this.houseRent = houseRent;
	}

	public String getFinish() {
		return finish;
	}

	public void setFinish(String finish) {
		this.finish = finish;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public Facility getFacility() {
		return facility;
	}

	public void setFacility(Facility facility) {
		this.facility = facility;
	}

	public String getPlotId() {
		return plotId;
	}

	public void setPlotId(String plotId) {
		this.plotId = plotId;
	}

	public Village getVillage() {
		return village;
	}

	public void setVillage(Village village) {
		this.village = village;
	}

	public String getRentOutId() {
		return rentOutId;
	}

	public void setRentOutId(String rentOutId) {
		this.rentOutId = rentOutId;
	}

	public RentOut getRentOut() {
		return rentOut;
	}

	public void setRentOut(RentOut rentOut) {
		this.rentOut = rentOut;
	}

	public String getHouseInfoId() {
		return houseInfoId;
	}

	public void setHouseInfoId(String houseInfoId) {
		this.houseInfoId = houseInfoId;
	}

	public HouseInfo getHouseInfo() {
		return houseInfo;
	}

	public void setHouseInfo(HouseInfo houseInfo) {
		this.houseInfo = houseInfo;
	}

	public List<FacilityHouse> getFacilityHouse() {
		return facilityHouse;
	}

	public void setFacilityHouse(List<FacilityHouse> facilityHouse) {
		this.facilityHouse = facilityHouse;
	}

	@Override
	public String toString() {
		return "HouseResource [houseId=" + houseId + ", himage=" + himage + ", descPict=" + descPict + ", scale="
				+ scale + ", area=" + area + ", houseRent=" + houseRent + ", finish=" + finish + ", facilityId="
				+ facilityId + ", facility=" + facility + ", plotId=" + plotId + ", village=" + village + ", rentOutId="
				+ rentOutId + ", rentOut=" + rentOut + ", houseInfoId=" + houseInfoId + ", houseInfo=" + houseInfo
				+ ", facilityHouse=" + facilityHouse + "]";
	}

}
