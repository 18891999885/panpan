package com.czxy.house.domain;

import javax.persistence.Id;

public class FacilityHouse {
  @Id
  private String facilityId;
  private String houseId;
  private Facility facility;


  public String getFacilityId() {
    return facilityId;
  }

  public void setFacilityId(String facilityId) {
    this.facilityId = facilityId;
  }


  public String getHouseId() {
    return houseId;
  }

  public void setHouseId(String houseId) {
    this.houseId = houseId;
  }

  public Facility getFacility() {
    return facility;
  }

  public void setFacility(Facility facility) {
    this.facility = facility;
  }

  @Override
  public String toString() {
    return "FacilityHouse{" +
            "facilityId='" + facilityId + '\'' +
            ", houseId='" + houseId + '\'' +
            ", facility=" + facility +
            '}';
  }
}
