package com.czxy.house.domain;

import javax.persistence.Id;

/*
 * 配置设施表
 */
public class Facility {
	@Id
    private String facilityId;	//配置设施id

    private String facilityName;//配置设施name

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId == null ? null : facilityId.trim();
    }

    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName == null ? null : facilityName.trim();
    }
}