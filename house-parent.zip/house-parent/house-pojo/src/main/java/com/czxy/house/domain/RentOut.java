package com.czxy.house.domain;
/*
 * 出租类型表
 */
public class RentOut {
    private String rentOutId;	//出租类型id

    private String rentOutType;		//出租类型
    
    private String rimage;
    

    public String getRimage() {
		return rimage;
	}

	public void setRimage(String rimage) {
		this.rimage = rimage;
	}

	public String getRentOutId() {
        return rentOutId;
    }

    public void setRentOutId(String rentOutId) {
        this.rentOutId = rentOutId == null ? null : rentOutId.trim();
    }

    public String getRentOutType() {
        return rentOutType;
    }

    public void setRentOutType(String rentOutType) {
        this.rentOutType = rentOutType == null ? null : rentOutType.trim();
    }

	@Override
	public String toString() {
		return "RentOut [rentOutId=" + rentOutId + ", rentOutType=" + rentOutType + ", rimage=" + rimage + "]";
	}
    
}