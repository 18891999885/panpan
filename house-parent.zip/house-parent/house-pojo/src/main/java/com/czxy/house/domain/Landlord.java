package com.czxy.house.domain;

import javax.persistence.Column;
import javax.persistence.Id;

/*
 * 房东
 */
public class Landlord {	
	@Id
	@Column(name="landlord_id")
    private String landlordId;	//房东id

    private String landlordName;//房东姓名

    private String phone;	//手机号

    private String landlordDate;	//起租房日期

    private String houseId;		//房源id
    private HouseResource houseResource;	//房源对象
	public String getLandlordId() {
		return landlordId;
	}
	public void setLandlordId(String landlordId) {
		this.landlordId = landlordId;
	}
	public String getLandlordName() {
		return landlordName;
	}
	public void setLandlordName(String landlordName) {
		this.landlordName = landlordName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getLandlordDate() {
		return landlordDate;
	}
	public void setLandlordDate(String landlordDate) {
		this.landlordDate = landlordDate;
	}
	public String getHouseId() {
		return houseId;
	}
	public void setHouseId(String houseId) {
		this.houseId = houseId;
	}
	public HouseResource getHouseResource() {
		return houseResource;
	}
	public void setHouseResource(HouseResource houseResource) {
		this.houseResource = houseResource;
	}
	public Landlord(String landlordId, String landlordName, String phone, String landlordDate, String houseId,
			HouseResource houseResource) {
		super();
		this.landlordId = landlordId;
		this.landlordName = landlordName;
		this.phone = phone;
		this.landlordDate = landlordDate;
		this.houseId = houseId;
		this.houseResource = houseResource;
	}
	public Landlord() {
		super();
	}
	@Override
	public String toString() {
		return "Landlord [landlordId=" + landlordId + ", landlordName=" + landlordName + ", phone=" + phone
				+ ", landlordDate=" + landlordDate + ", houseId=" + houseId + ", houseResource=" + houseResource + "]";
	}
    
    
}