package com.czxy.house.domain;

import org.springframework.format.annotation.DateTimeFormat;

public class LandlordVo {

    private String landlordName;
    private  String phone;
    private String landlordDate;
    private String rentOut;
    private String village;
    private String scale;
    private Double houseRent;


    @Override
    public String toString() {
        return "LandlordVo{" +
                "landlordName='" + landlordName + '\'' +
                ", phone='" + phone + '\'' +
                ", landlordDate='" + landlordDate + '\'' +
                ", rentOut='" + rentOut + '\'' +
                ", village='" + village + '\'' +
                ", scale='" + scale + '\'' +
                ", houseRent='" + houseRent + '\'' +
                '}';
    }

    public void setLandlordName(String landlordName) {
        this.landlordName = landlordName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setLandlordDate(String landlordDate) {
        this.landlordDate = landlordDate;
    }

    public void setRentOut(String rentOut) {
        this.rentOut = rentOut;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }

    public void setHouseRent(Double houseRent) {
        this.houseRent = houseRent;
    }

    public String getLandlordName() {

        return landlordName;
    }

    public String getPhone() {
        return phone;
    }

    public String getLandlordDate() {
        return landlordDate;
    }

    public String getRentOut() {
        return rentOut;
    }

    public String getVillage() {
        return village;
    }

    public String getScale() {
        return scale;
    }

    public Double getHouseRent() {
        return houseRent;
    }
}
